# Proxy Builder Android Project
This is the complete Android Studio wrapper project for Proxy Builder.
1. Open this folder in Android Studio
2. Click Build -> Build Bundle(s) / APK(s) -> Build APK(s)
3. Your output APK will be in app/build/outputs/apk/debug/app-debug.apk
